package application;

import java.io.File;
import java.nio.file.Paths;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Path;
import javafx.stage.Stage;

public class DENEME extends Application {

    private static final String IMAGE_PATH = "levels\\house.jpg";
    private static final double CIRCLE_RADIUS = 100;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Pane root = new Pane();
        File file = new File(IMAGE_PATH);
        // Daireleri oluşturma ve resimleri yerleştirme
        Circle circle1 = createCircle(200, 200, CIRCLE_RADIUS, file.getAbsolutePath());
        Circle circle2 = createCircle(400, 300, CIRCLE_RADIUS, file.getAbsolutePath());

        root.getChildren().addAll(circle1, circle2);

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Circle createCircle(double centerX, double centerY, double radius, String imagePath) {
        // Daire oluşturma
        Circle circle = new Circle(centerX, centerY, radius);
        circle.setFill(new ImagePattern(new Image(imagePath)));

        return circle;
    }
	/*for(int a=0;a<cities.size();a++) {
		if(cities.get(a)!=null)
		System.out.println(cities.get(a).cityName);
	}*/
}