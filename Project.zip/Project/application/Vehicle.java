package application;

public class Vehicle {
	public int currentCityId;
	public int passengerCapacity;
	
	public Vehicle(int currentCityId, int passengerCapacity) {
		this.currentCityId = currentCityId;
		this.passengerCapacity = passengerCapacity;
	}
}
