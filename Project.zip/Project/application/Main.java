package application;
	
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Text;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class Main extends Application {
	public static int level =0;
	public ArrayList<City> cities=new ArrayList<City>();
	@Override
	public void start(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		BorderPane top = new BorderPane();
		Pane center = new Pane();
		BorderPane bottom = new BorderPane();
		
		addCity1(91,pane,center);
		addCity1(100,pane,center);
		addCity1(1,pane,center);
		addCity1(10,pane,center); 
		addFixed(55,pane,center);
		addFixed(91,pane,center);
		addFixed(100,pane,center);
		addFixed(10,pane,center);
		addFixed(1,pane,center);
		addVehicle(5,pane,center,10);
		
		top.setStyle("-fx-border-color: black");
		bottom.setStyle("-fx-border-color: black");
		center.setStyle("-fx-border-color: black");
		
		StackPane topLeft = new StackPane();
		topLeft.getChildren().add(new Text("Level: " + level));
		topLeft.setPadding(new Insets(2,2,2,2));
		
		StackPane topRight = new StackPane();
        Button nextLevel = new Button("Next Level>>");
        class LevelHandler implements EventHandler<ActionEvent> {
            @Override
            public void handle(ActionEvent arg0) {
            	level++;
            	topLeft.getChildren().clear();
            	topLeft.getChildren().add(new Text("Level: " + level));
            	center.getChildren().clear();
            	levelInitializer("level"+level+".txt",pane,center);
            	
            }
        }
        nextLevel.setOnAction(new LevelHandler());
        topRight.getChildren().add(nextLevel);
		
		StackPane topMid = new StackPane();
		topMid.getChildren().add(new Text("Score:"));
			
		
		StackPane bottomRight = new StackPane();
		bottomRight.setAlignment(Pos.CENTER_RIGHT);
		Font font = new Font(30);
		Button button = new Button("DRIVE");
		button.setFont(font);
		button.setStyle("-fx-background-color: transparent; -fx-border-width: 0;");
		
		bottomRight.getChildren().add(button);
		bottomRight.setPadding(new Insets(50,10,50,10));
		
		FlowPane bottomLeft = new FlowPane();
		bottomLeft.setPadding(new Insets(2,2,2,2));
		bottomLeft.setAlignment(Pos.TOP_LEFT);
		
		top.setLeft(topLeft);
		top.setRight(topRight);
		top.setCenter(topMid);
		bottom.setRight(bottomRight);
		bottom.setLeft(bottomLeft);
		pane.setTop(top);
		pane.setCenter(center);
		pane.setBottom(bottom);
		
		Scene scene = new Scene(pane,600,790);
		primaryStage.setTitle("Travel");
		primaryStage.setScene(scene);
		primaryStage.show();	
	}
	
	public static void main(String[] args) {
		launch(args);
	}

	public void addCity1(int x,Pane pane,Pane center){
		int o=x;
		x--;
		int a=x/10;
		int b=x%10;
		File file = new File("levels\\city"+(int)(Math.random()*6+1)+".jpg");
		Circle c1 = createCircle(30+60*b,30+60*a, 30, file.getAbsolutePath());
		c1.radiusProperty().bind((center.heightProperty()).divide(20));
		c1.centerXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(c1.radiusProperty()).add((pane.widthProperty().divide(2))));
		c1.centerYProperty().bind ((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty()));
		center.getChildren().add(c1);
		Button deneme = new Button("   ");
		Font asd = new Font(30);
		deneme.setStyle("-fx-background-color: transparent; -fx-border-width: 0;");
		deneme.setFont(asd);
		center.getChildren().add(deneme);
		deneme.setLayoutX(450);
		deneme.setLayoutY(300);
        Circle buttonCircle = new Circle(60);
        buttonCircle.radiusProperty().bind((pane.heightProperty().subtract(190)).divide(20));
		deneme.setShape(buttonCircle);
		deneme.layoutXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(c1.radiusProperty()).add((pane.widthProperty().divide(2)).subtract(32)));
		deneme.layoutYProperty().bind ((center.heightProperty()).divide(10).multiply(a).subtract(33).add(c1.radiusProperty()));
		class Deneme implements EventHandler<ActionEvent> {
            @Override
            public void handle(ActionEvent arg0) {
            	System.out.println("BAŞARILI");
            	for(int a=0;a<cities.size();a++) {
            		if(cities.get(a)!=null)
            		if(cities.get(a).coordinate==o)
            			getInfo(cities.get(a));
            	}
            	
            }
        }
		deneme.setOnAction(new Deneme());
		
		
	}
	public void addFixed(int x,Pane pane,Pane center){
		x--;
		int a=x/10;
		int b=x%10;
		Circle c1 =new Circle(30+60*b,53+60*a, 30);
		c1.setStroke(Color.RED);
		c1.setFill(Color.WHITE);
		c1.radiusProperty().bind((center.heightProperty()).divide(20));
		c1.centerXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(c1.radiusProperty()).add((pane.widthProperty().divide(2))));
		c1.centerYProperty().bind ((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty()));
		center.getChildren().add(c1);
		Line line1 = new Line();
		center.getChildren().add(line1);
		line1.startXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(300).add(c1.radiusProperty()).add((pane.widthProperty().divide(2)).subtract(300)).subtract(c1.radiusProperty().divide(3)));
		line1.startYProperty().bind((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty()).subtract(c1.radiusProperty().divide(3)));
		line1.endXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(300).add(c1.radiusProperty()).add((pane.widthProperty().divide(2)).subtract(300)).add(c1.radiusProperty().divide(3)));
		line1.endYProperty().bind((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty()).add(c1.radiusProperty().divide(3)));
		
		Line line2 = new Line();
		center.getChildren().add(line2);
		line2.startXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(c1.radiusProperty()).add((pane.widthProperty().divide(2))).subtract(c1.radiusProperty().divide(3)));
		line2.startYProperty().bind((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty()).add(c1.radiusProperty().divide(3)));
		line2.endXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(c1.radiusProperty()).add((pane.widthProperty().divide(2))).add(c1.radiusProperty().divide(3)));
		line2.endYProperty().bind((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty()).subtract(c1.radiusProperty().divide(3)));
		
		
	}
	public void addVehicle(int city,Pane pane,Pane center,int capacity) {
		int x=0;
		for(int k=0;k<cities.size();k++) {
			if(cities.get(k)!=null) {
				if(cities.get(k).cityNumber==city)
					x=cities.get(k).coordinate;
			}		
		}
		x--;
		int a=x/10;
		int b=x%10;
		File file;
		if(capacity<6)
			file = new File("levels\\vehicle1.png");
		else if(capacity<14)
			file = new File("levels\\vehicle2.png");
		else
			file = new File("levels\\vehicle3.png");
		Circle c1 = createCircle(30+60*b,30+60*a, 20, file.getAbsolutePath());
		c1.radiusProperty().bind((center.heightProperty()).divide(15));
		c1.centerXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(c1.radiusProperty()).add((pane.widthProperty().divide(2)).add(10)));
		c1.centerYProperty().bind ((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty().add(10)));
		
			
		center.getChildren().add(c1);
		
	}
	
	
	public void levelInitializer(String filename,Pane pane,Pane center) {
		try {
			center.getChildren().clear();
			cities.clear();
			java.io.File file = new java.io.File("levels\\"+filename);
			Scanner scanner = new Scanner(file);
			while(scanner.hasNextLine()) {
				String item = scanner.nextLine();
				System.out.println(item);
				addItem(item,pane,center);
				
				
				/*if(addItem(item) instanceof City) {
					City city = (City)addItem(item);
					
				}*/
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addItem(String item,Pane pane,Pane center) {
		int first,second,third;
		switch (item.charAt(0)) {
			case 'C' : 	first = item.indexOf(',');
						second = item.indexOf(',', first+1);
						third = item.indexOf(',', second+1);
						addCity1(Integer.parseInt(item.substring(second+1, third)),pane,center);
						City city = new City(item.substring(first+1, second), Integer.parseInt(item.substring(second+1, third)), Integer.parseInt(item.substring(third+1)));
						if (cities.size()<Integer.parseInt(item.substring(third+1))){
							for(int a=Integer.parseInt(item.substring(third+1));a>cities.size();){
								cities.add(null);
							}
						}
						cities.add(Integer.parseInt(item.substring(third+1)), city);
						if(cities.size()>Integer.parseInt(item.substring(third+1))+1)
							cities.remove(Integer.parseInt(item.substring(third+1))+1);
						break;
			case 'P' :	first = item.indexOf(',');
						second = item.indexOf(',', first+1);
						third = item.lastIndexOf(',');
						City currentCity1=cities.get(Integer.parseInt(item.substring(second+1, third)));
						City currentCity2=cities.get(Integer.parseInt(item.substring(third+1)));
						Passenger passenger = new Passenger(Integer.parseInt(item.substring(first+1, second)), Integer.parseInt(item.substring(second+1, third)), Integer.parseInt(item.substring(third+1)),currentCity1.cityName,currentCity2.cityName);
						for(int a=0;a<cities.size();a++) {
							if(cities.get(a)!=null) {
								if(cities.get(a).cityNumber==Integer.parseInt(item.substring(second+1, third)))
									cities.get(a).passengers.add(passenger);
								if(cities.get(a).cityNumber==Integer.parseInt(item.substring(third+1)))
									cities.get(a).arrivals.add(passenger);
							}
								
						}
						break;
			case 'V' :	first = item.indexOf(',');
						second = item.indexOf(',', first+1);
						third = item.indexOf(',', second+1);
						Vehicle vehicle = new Vehicle(Integer.parseInt(item.substring(first+1, second)), Integer.parseInt(item.substring(second+1)));
						addVehicle(cities.get(Integer.parseInt(item.substring(first+1, second))).cityNumber, pane, center, (Integer.parseInt(item.substring(second+1))));
						
						break;
			case 'F' :	first = item.indexOf(',');
							addFixed(Integer.parseInt(item.substring(first+1)),pane,center);
						Fixed fixed = new Fixed(Integer.parseInt(item.substring(first+1)));
						break;
			default  :	break;
		}
	}
	private Circle createCircle(double centerX, double centerY, double radius, String imagePath) {
        Circle circle = new Circle(centerX, centerY, radius);
        circle.setFill(new ImagePattern(new Image(imagePath)));

        return circle;
    }
	public void getInfo(City city) {
		
        for(int i = 0; i < city.arrivals.size(); i++) {
            System.out.println(city.arrivals.get(i).startingCityName + " > " + city.cityName + " ( " +  city.arrivals.get(i).numberOfPassenger + " Passengers)");
        }
        if(true){
            for(int i = 0; i < city.passengers.size(); i++) {
                System.out.println(city.cityName + " > " + city.passengers.get(i).destinationCityName + " ( " +  city.passengers.get(i).numberOfPassenger + " Passengers)");
            }
        }
    }
	public double distance(int first,int second) {
		first--;
		second--;
		int x1=first%10;
		int y1=first/10;
		int x2=first%10;
		int y2=second/10;
		return Math.sqrt((Math.pow(x2-x1,2)+Math.pow(y2-y1,2)));
		
	}
	public void addLine(int city,Pane pane,Pane center,int capacity) {
		int x=0;
		for(int k=0;k<cities.size();k++) {
			if(cities.get(k)!=null) {
				if(cities.get(k).cityNumber==city)
					x=cities.get(k).coordinate;
			}		
		}
		x--;
		int a=x/10;
		int b=x%10;
		c1.radiusProperty().bind((center.heightProperty()).divide(15));
		c1.centerXProperty().bind((center.heightProperty()).divide(10).multiply(b-5).add(center.heightProperty()).divide(15).add((pane.widthProperty().divide(2)).add(10)));
		c1.centerYProperty().bind ((center.heightProperty()).divide(10).multiply(a).add(c1.radiusProperty().add(10)));
		
			
		center.getChildren().add(c1);
		
	}
}


